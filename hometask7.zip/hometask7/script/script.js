// 1. Написать функцию, получающую на вход два числа. Если оба числа чётные - функция возвращает их произведение. Если оба числа нечётные - функция возвращает их сумму. Если одно из чисел чётное, а второе нечётное - функция возвращает это нечётное число.

function setResult(number1 = 0, number2 = 0){
if(number1 % 2 == 0 & number2 % 2 == 0){
    return number1 * number2;
} 
if (number1 % 2 != 0 & number2 % 2 != 0){
    return number1 + number2;
} 
if(number1 % 2 != 0) return number1;
else return number2;
}

console.log(setResult(5, 7));
console.log(setResult(4, 8));
console.log(setResult(5, 8));
console.log(setResult(4, 11));

// 2. Написать  функцию, которая параметром будет принимать секунды, а возвращать количество суток, соответствующих этим секундам.

function getDay (sec = 0){
    return Math.round(sec / 86400);
}

console.log(getDay(645242322));

// 3. Написать функцию isPrime, которая принимает число и возвращает true, если оно простое (имеет только два делителя: 1 и само число), и false в противном случае.

function isPrime(num = 0){
    let count = 0;
    for (let i = num; i >= 1; i--){
        if(num % i == 0) count++
    }
    if(count == 2) return true;
    else return false;
}

console.log(isPrime(7));
console.log(isPrime(8));

// 4. Написать функцию, которая в качестве аргументов получает два числа и выводит в консоль наименьшее.

function getLeast(num1 = 0, num2 = 0){
    if(num1 < num2) return num1;
    if(num2 < num1) return num2;
    if(num1 == num2) return "Numbers are equal"
}

console.log(getLeast(6, 5));
console.log(getLeast(6, 7));
console.log(getLeast(8, 8));

// 5. Написать  функцию, которая в качестве аргументов получает два числа и возвращает массив чисел со значениями от меньшего числа к большему. 

function getArray(numb1 = 0, numb2 = 0) {
    let arr = [];
    let max = 0;
    let min = 0;
    if (numb1 > numb2) {
        max = numb1;
        min = numb2;
    } else if(numb1 < numb2){
        max = numb2;
        min = numb1;
    } else return [numb1];
    for (let i = min; i <= max; i++){
        arr.push(i);
    }
    return arr;
}

console.log(getArray(3, 17));
console.log(getArray(10, 2));
console.log(getArray(4, 4));