//  1. Создайте новый элемент 
// , добавьте ему текст и добавьте его после элемента с id "existingElement".

let elem1 = document.createElement('p');
elem1.innerText = "Element1";
let existingElement = document.querySelector('#existingElement');
existingElement.after(elem1);

// 2. Создайте новый элемент , добавьте ему текст и вставьте его внутрь элемента с id "parentElement".

let elem2 = document.createElement('p');
elem2.innerText = "Element2";
let parentElement = document.querySelector('#parentElement');
parentElement.append(elem2);

// 3. Удалите элемент с классом "removeMe".

let removeMe = document.querySelector('.removeMe');
removeMe.remove();

// 4. Создать множество карточек с товарами (на основе массива с объектами. У объекта свойства title, unit_price, count)

let arr = [
    {
        title: 'title1',
        unit_price: 1000,
        count: 8
    },
    {
        title: 'title2',
        unit_price: 2000,
        count: 12
    },
    {
        title: 'title3',
        unit_price: 3000,
        count: 30
    },
    {
        title: 'title4',
        unit_price: 400,
        count: 4
    }
]

for(elem1 of arr){
    let card = document.createElement('div');
    document.body.append(card);
    for(el in elem1){
        let paragraph = document.createElement('p');
        paragraph.innerText = `${el}: ${elem1[el]}`;
        card.append(paragraph);
    }
}


// 5. Написать скрипт, который выводит карточки с товарами в интерфейс (на основе массива с объектами. У объекта свойства title, unit_price, count), а внизу выводится итоговая сумма товаров и их количество.

function products (array = []){
    let sum = 0;
    let quantity = 0;
    for(elem1 of array){
        let card = document.createElement('div');
        document.body.append(card);
        sum ++;
        quantity += elem1.count;
        for(el in elem1){
            let paragraph = document.createElement('p');
            paragraph.innerText = `${el}: ${elem1[el]}`;
            card.append(paragraph);
        }
    }
    let divSum = document.createElement('div');
    divSum.innerText = `Всего товаров: ${sum}`;
    document.body.append(divSum);
    let divQuantity = document.createElement('div');
    divQuantity.innerText = `Количество: ${quantity}`;
    document.body.append(divQuantity);
    
}
products(arr);